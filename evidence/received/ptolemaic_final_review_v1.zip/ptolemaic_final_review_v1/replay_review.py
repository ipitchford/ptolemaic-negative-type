#!/usr/bin/env python3
"""Verify archive integrity and replay evidence without changing shipped files.

No network access is used. Exact identities are checked in every mode. Full
mode also replays numerical corroboration and the three supplied audit scripts.
Numerical byte differences are reported, not silently converted into failures
or into proofs of a universal claim.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

ROOT=Path(__file__).resolve().parent

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def manifest() -> int:
    path=ROOT/'SHA256SUMS'
    if not path.is_file(): raise RuntimeError('Missing top-level SHA256SUMS.')
    count=0
    for line in path.read_text().splitlines():
        digest,name=line.split('  ',1)
        file=(ROOT/name).resolve()
        if not file.is_relative_to(ROOT) or not file.is_file():
            raise RuntimeError(f'Invalid or missing manifest file: {name}')
        if sha(file)!=digest: raise RuntimeError(f'Checksum mismatch: {name}')
        count+=1
    return count

def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode',choices=('integrity','exact','full'),default='exact')
    parser.add_argument('--output',type=Path,help='An output directory outside this review bundle.')
    parser.add_argument('--timeout',type=int,default=900,help='Maximum seconds for each script; default 900.')
    args=parser.parse_args()
    if sys.flags.optimize: raise RuntimeError('Run without -O: archived exact verifiers use assertions.')
    count=manifest()
    if args.output:
        out=args.output.expanduser().resolve()
        if out.is_relative_to(ROOT): raise RuntimeError('Choose an output directory outside the immutable review bundle.')
        out.mkdir(parents=True,exist_ok=True)
    else:
        out=Path(tempfile.mkdtemp(prefix='ptolemaic-review-'))
    result={'version':'1.0-rc1','mode':args.mode,'manifest_files_verified':count,
            'formal_proof_assistant_used':False,'jobs':[],
            'scope':'Proof-supporting identities and bounded numerical corroboration; the analytic proof is in paper/ptolemaic.pdf.'}
    env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',
             PYTHONHASHSEED='0',PYTHONDONTWRITEBYTECODE='1',PYTHONOPTIMIZE='0')
    def run(name,cmd,cwd,reports):
        print(f'Running {name}',flush=True)
        start=time.monotonic()
        process=subprocess.run(cmd,cwd=cwd,env=env,capture_output=True,text=True,timeout=args.timeout)
        (out/f'{name}.log').write_text(process.stdout+'\n--- STDERR ---\n'+process.stderr)
        entry={'job':name,'exit_code':process.returncode,'elapsed_seconds':round(time.monotonic()-start,3),'reports':{}}
        if process.returncode:
            result['jobs'].append(entry)
            raise RuntimeError(f'{name} failed; see {out/name}.log')
        for rel,reference,exact in reports:
            file=cwd/rel
            if not file.is_file(): raise RuntimeError(f'{name} did not produce {rel}')
            target=out/f'{name}__{file.name}'; shutil.copy2(file,target)
            equal=file.read_bytes()==reference.read_bytes()
            entry['reports'][rel]={'sha256':sha(file),'matches_shipped_bytes':equal,
                                   'exact_byte_match_required':exact}
            if exact and not equal: raise RuntimeError(f'Exact report differs: {name}/{rel}')
        result['jobs'].append(entry)
    try:
        if args.mode!='integrity':
            with tempfile.TemporaryDirectory(prefix='ptolemaic-replay-work-') as temp:
                work=Path(temp); core=work/'core'; supplied=work/'supplied'
                shutil.copytree(ROOT/'evidence/core',core)
                shutil.copytree(ROOT/'evidence/supplied',supplied)
                if args.mode=='full':
                    run('core_replay',[sys.executable,'replay.py'],core,
                        [('checks/exact_results.json',ROOT/'evidence/core/checks/exact_results.json',True),
                         ('checks/symbolic_results.json',ROOT/'evidence/core/checks/symbolic_results.json',True),
                         ('checks/numerical_results.json',ROOT/'evidence/core/checks/numerical_results.json',False)])
                else:
                    run('core_exact',[sys.executable,'verify_exact.py'],core,
                        [('checks/exact_results.json',ROOT/'evidence/core/checks/exact_results.json',True)])
                    run('core_symbolic',[sys.executable,'verify_symbolic.py'],core,
                        [('checks/symbolic_results.json',ROOT/'evidence/core/checks/symbolic_results.json',True)])
                run('manuscript_checks',[sys.executable,str(ROOT/'scripts/verify_manuscript.py'),
                                          '--output',str(work/'manuscript_checks.json')],work,
                    [('manuscript_checks.json',ROOT/'evidence/current/manuscript_checks.json',True)])
                if args.mode=='full':
                    for job in ('audit_allsize','near_extremal','adversarial_lemma4'):
                        run(job,[sys.executable,f'{job}.py'],supplied,
                            [(f'{job}.json',ROOT/f'evidence/supplied/{job}.json',False)])
        result['status']='PASS'
        result['manifest_files_verified_after_replay']=manifest()
    except Exception as error:
        result['status']='FAIL'; result['error']=str(error)
        (out/'REPLAY_REPORT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
        raise
    (out/'REPLAY_REPORT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(f"PASS: {count} shipped files verified; {len(result['jobs'])} jobs completed.")
    print(f'Reports: {out}')
    print('This is not proof-assistant verification or an exhaustive numerical search.')
    return 0

if __name__=='__main__':
    try: raise SystemExit(main())
    except Exception as error:
        print(f'ERROR: {error}',file=sys.stderr); raise SystemExit(1)
