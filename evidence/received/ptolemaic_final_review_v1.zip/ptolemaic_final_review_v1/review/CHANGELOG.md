# Changes for version 1.0-rc1

## Mathematical presentation

- Recast the research note as a fourteen-page review paper with an abstract, numbered theorems/equations, prior-work discussion, sharpness proof and two appendices.
- State the self-contained range `m≥6` separately from the all-cardinality corollary using the imported four- and five-point endpoints.
- Preserve the scalar, packing and inverse-correlation mechanisms. No discarded mass inequality has been reintroduced.
- Rename the root-dependent mixed inverse pairing from `M` to `μ` and rename its positive quadratic pairings to `U,V`, avoiding confusion with the established metric M-constant and the threshold `P(m)`.
- Make the hypothesis `S_p(j)` explicitly universal over all Ptolemaic metrics of cardinality at most j, including inversions of the current metric.
- Display the block congruence, proper-subset cardinality guard, parameter guard, signed deletion cases and square-completion identity at the steps where they are used.
- Retain the zero truncations in `L_n` and `k_n` and discuss their degenerate cases.
- Add an elementary derivation of the three-point endpoint, the matrix normalisation behind the BHKL correspondence and the immediate asymptotic constant.
- Preserve exact counterexamples to the two failed auxiliary claims in Appendix A. Appendix B supplies the induction dependency table.

## Evidence and provenance

- Preserve all three received ZIPs exactly, with their checksums and sizes.
- Replay the original core checks and all three supplied audit scripts in temporary copies. Preserve both received and new numerical reports.
- Add supplemental manuscript-specific identity checks, explicit environment records, a no-network replay wrapper and a no-network LaTeX build script.
- Correct evidence interpretation: distinguish the empty original near-extremal sample from the successful follow-up; record numerical tolerance, mixed statistics, accepted-count definitions and optimiser output differences.
- Do not copy subjective probability estimates or quality scores into the manuscript's assurance statement.
- Leave authorship/release accountability, licensing, DOI, journal and public-deposition fields unassigned. No new public release has occurred.

## Unchanged limitations

The prose proof has not been checked by a proof assistant or an identified external specialist. Historical novelty is not exhaustively verified. The proof does not classify all extremisers. Exact or symbolic checks of identities do not themselves certify the universal mathematical argument.
