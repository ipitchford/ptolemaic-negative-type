# Final-review guide
## Sharp negative type of finite Ptolemaic metrics
**Version 1.0-rc1 · 25 September 2026 · Anonymous review copy**

### 1. Scope of this review

The manuscript presents an analytic proof draft of the sharp universal exponent for every Ptolemaic metric with at least six points. It appends the established small endpoints to obtain the all-size formula. This package is for mathematical review, not a record of public acceptance or a formal proof certificate.

The main result is Theorem 1.1; Corollary 1.2 gives all cardinalities and the triangular-hyperfield threshold. The main proof is self-contained in elementary analysis, finite-dimensional convexity and linear algebra. Ercan's five-point endpoint is used only to complete the formula at five points.

### 2. Read these three arguments first

**Star packing (Theorem 3.4).** Check the supporting-power inequality for every positive ratio; the opposite ordering of lengths and positive full-support solutions; and the vertex argument. A vertex with all coordinates positive must activate every row constraint. Dropping zero coordinates weakens constraints and preserves a smaller packing problem. No sign assumption is made about the star's own inverse vectors.

**Inverse correlations (Theorem 5.1).** The universal strictness hypothesis must cover inverted metrics, not merely subsets of one array. Check pair-complement inertia, the signed deletion formula, the exhaustive three-way sign split, and both zero-truncated parameter cases. The conditional theorem does not assert strictness of the final metric in the outer induction.

**Cardinality (Proposition 6.1).** Each pairwise Schur estimate uses only `a+2 ≤ m−1` metric points. Check the common exponent, the parameter guard from `a≤r`, and completion of the square without prior positivity of the full Gram matrix. Endpoint passage is pointwise; sharpness is a fixed split metric at every larger exponent. Appendix B separates the two inductions.

An objection should identify the theorem or equation, the missing hypothesis or invalid inference, and its effect on the main result. A numerical discrepancy should include its input array, admissibility check, precision and conditioning.

### 3. Dependencies and nonclaims

| Statement | Source or status |
|---|---|
| Sharp threshold for all `m≥6` | Analytic proof in the manuscript. |
| `P(3)=2` | Elementary Euclidean triangle and split witness, reproved. |
| `P(4)=log₂3` | BHKL v2, Theorem 7.16 / Corollary 7.17. |
| `P(5)=log₂(9/4)` | Ercan v1, Theorem 1.1; its complete certificate is not replayed here. |
| `q(n)=P(n−1)` | BHKL Proposition 7.5; normalisation reproduced in Section 7.1. |
| Formalisation, equality classification, exhaustive priority check | Not supplied or claimed. |

Classical Gram, inverse-distance and circumcentre objects are attributed to their existing literature. The root-dependent mixed pairing is called `μ`, not identified with the classical metric M-constant. No external specialist review has been verified.

\newpage

### 4. What the evidence establishes

The original rational and symbolic reports reproduce byte-for-byte. The core numerical report and separate near-extremal report also reproduce exactly in the recorded environment. The supplied general audit and adversarial optimisation have floating-point differences; adversarial feasible counts change too. Both original and fresh records are preserved.

The new manuscript checker reconstructs thirteen groups of exact identities and finite sanity checks. It includes the square completion with an indefinite full block, the classical inverse pairing, compatibility factors, proper-subset guards and the eleven-point endpoint. These programs support the written proof; they do not formalise the universal analytic induction.

Run `python replay_review.py --mode exact` for the exact layer, or `--mode full` for the numerical corroboration as well. The wrapper validates hashes and executes temporary copies. It does not overwrite shipped evidence. Details are in `CLAIM_CHECK_MAP.csv`, `EVIDENCE_LEDGER.md` and the recorded environment.

### 5. Numerical limitations that affect interpretation

The broad audit's first near-extremal stage accepted **zero** candidates at each of 11–14 points. Its stored `1e9` is an initial sentinel, not an eigenvalue bound. The separate follow-up supplies 600 accepted samples per size, or 2,400 in total, using floating feasibility tolerance `1e-9`.

The follow-up field `min_eig_centred_Gram` also includes an unnormalised quadratic-form test, so it is not solely an eigenvalue statistic. A centred Gram matrix has a structural zero eigenvalue; minima around `10⁻¹⁶` do not establish a positive spectral margin.

The adversarial search allows constraint residuals down to `−10⁻⁸`, does not require the optimiser success flag and does not save its extremising arrays. Tiny positive deficits are not certified counterexamples. The received feasible counts were `40,40,39,38`; the current replay gives `40,40,40,40`. At `n=3` the exponent is capped below one, so this run is not near the algebraic boundary `T=3`. The ledger gives all bounds and differences.

The supplied confidence probability and quality score are subjective judgements, not calibration data. They remain in the received archive and are not used as scientific assurance in the paper. The supplied audit's author identity and independence have not been independently established.

### 6. Formalisation and release hand-off

Formalisation can follow the paper's dependency order: supporting-power inequality and star packing; augmented inverse, deletion and inertia; conditional correlation induction; outer cardinality induction and endpoint continuity. A finite check through any cardinality does not discharge either induction in a proof assistant.

The two failed inverse-pairing claims are retained with exact counterexamples in Appendix A; neither is used in the proof. The review paper has stable theorem numbering and explicit strictness hypotheses. Historical inputs remain unchanged.

No DOI, licence grant, journal submission or public deposition has been created. An accountable releasing party, attribution, licence and release identifiers remain unassigned. These are release decisions, not missing mathematical lemmas.

### Sanity check

At eleven points the split is `(a,r)=(5,6)` and `T=36/25`. The rational powered array has centred Gram eigenvalues `1/2` (multiplicity four), `18/25` (multiplicity five), and zero (multiplicity two). The signed coefficient vector lies in its kernel. The supplemental exact verifier reconstructs this without the discarded inverse-positivity assumptions.
