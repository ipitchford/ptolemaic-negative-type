# Evidence and missingness ledger
**Version 1.0-rc1 · Recorded 25 September 2026**

## Corpus and provenance

The input corpus is the three ZIPs in `evidence/received/`, with exact sizes and SHA-256 values in `INPUTS.json`. No supplied file has been silently repaired. `evidence/core/` is the original all-size proof package extracted unchanged. `evidence/supplied/` contains root-level audit scripts, JSON reports and notes copied from the publication-gate bundle. Nested originals remain accessible in the preserved archives.

The paper is a new synthesis of this corpus. The supplied favourable proof reading is evidence of an additional review artefact, not verified identity or statistical independence of an external specialist reader. The numerical probability and local quality score in the gate are subjective judgements. They do not enter any theorem, confidence interval or review status field here.

## Levels of assurance

- **Analytic proof:** the universal statements rest on the arguments in the paper.
- **Exact algebra:** `verify_exact.py`, `verify_symbolic.py`, and the additional manuscript checks test identities, finite rational arrays and parameter relations. Symbolic simplification is not a kernel-checked formalisation of the prose proof.
- **Numerical corroboration:** sampled scalar inequalities, linear programmes, eigenvalues and optimisations are bounded tests. Tolerances, conditioning and missing observations limit their interpretation.
- **External dependencies:** BHKL's four-point endpoint and Ercan's five-point endpoint are imported only for the small cases of the all-size corollary. Their complete proof certificates are not replayed here.
- **Absent assurance:** no Lean or other proof-assistant development, verified external specialist review, journal acceptance, DOI-backed public release, or exhaustive novelty search is represented by this package.

## Current replay receipt

The exact details and file hashes are in `evidence/current/REPLAY_REPORT.json`.

| Job | Exit | Byte comparison with received reports |
|---|---:|---|
| Original `replay.py` | 0 | Exact, symbolic, numerical and original replay report all identical. |
| `audit_allsize.py` | 0 | Different floating-point residuals and one least-significant numerical slack; counts and substantive observations agree. |
| `near_extremal.py` | 0 | Identical. |
| `adversarial_lemma4.py` | 0 | Different floating-point deficits; feasible counts change at `n=5,6`. |
| New manuscript checks | 0 | Thirteen groups of exact checks pass; report generated for this version. |

A later replay on another operating system, BLAS build or numerical-library version need not reproduce floating-point bytes. Exact output mismatches should be investigated. The wrapper reports both classes separately and runs supplied code only in temporary copies.

## Inspected numerical limitations

### E1. An empty sample was previously labelled as a near-extremal check

In `audit_allsize.json`, each of the four `final_theorem_near_extremal` records has `perturbed_Ptolemaic_metrics=0`. The `1e9` minimum is an initial sentinel left unchanged. These records contain no sampled endpoint eigenvalue evidence. The explicitly evaluated complete-split test at `p+0.001` is a separate observation and remains meaningful.

### E2. The follow-up really has 2,400 samples, but they are floating-point checks

`near_extremal.json` records 600 accepted samples at each of 11, 12, 13 and 14 points. Raw metric/Ptolemy feasibility is accepted with additive tolerance `1e-9`. The procedure is not exact rational validation. The statistic named `min_eig_centred_Gram` is the minimum of both an eigenvalue calculation and an unnormalised quadratic form, so it should not be called solely a spectral statistic. Moreover, centred Gram matrices always have a structural zero eigenvalue.

### E3. The adversarial run is a search, not a certificate

There are 40 starts at each `n=3,4,5,6`. The search uses log-distance bounds `[-4,4]`, a 300-iteration SLSQP cap, objective tolerance `1e-12` and a final feasibility allowance of `-1e-8`. The feasible counter ignores the optimiser success flag. Exceptions are caught without retaining a per-start failure ledger. Neither exact candidate arrays nor validated intervals are saved. No maximum over all Ptolemaic metrics is established.

The supplied feasible counts were `40,40,39,38`; the current replay gives `40,40,40,40`. Supplied maximum deficits were approximately `3.25e-12,1.06e-11,4.00e-13,1.39e-16`; current values are `3.25e-12,4.42e-14,2.22e-16,-1.67e-16`. Their scale is below the admitted feasibility tolerance. A positive value at that scale is not an admissible exact counterexample.

For `n=3`, the run uses `p=0.999`, not an exponent near `log₂3`; the proof regime itself has `p<1`. The other dimensions approach their effective upper parameter boundary. The search description has been bounded accordingly without changing its original source.

### E4. The random audit has accepted rather than attempted counts

The random-metric stage tries 1,500 candidates at each of five sizes and records accepted counts `1039,842,769,750,750`, totalling 4,150. They are not 7,500 independent admissible metrics. The scalar grid has 25 exponents and 4,001 ratios. Its derivative residual at a single rational point is a sample; the independent core symbolic verifier supplies the general symbolic identity check.

### E5. What the new checks do and do not add

`manuscript_checks.json` reconstructs thirteen groups, including 22,200 finite proper-subset cases through cardinality 300 and the exact eleven-point endpoint spectrum. Neither count is a proof for all cardinalities. The universal parameter guard is the displayed algebraic factorisation, and the universal theorem is the analytic induction.

## Original failed conjectures

The proposed inverse-pairing monotonicity and untruncated star bound are false. Appendix A supplies exact counterexamples and their sign arguments. The final proof uses neither, and makes no assumption that a star's own inverse vectors are nonnegative. The original input archives preserve the historical claims for auditability.

## Nonclaims retained in the paper

The result is a sharp universal exponent with explicit witnesses. It does not classify every equality metric, imply a normalised uniform stability gap, or establish that the new auxiliary lemmas have no prior appearance. A faithful replay supports the computations; it does not certify the interlocking universal hypotheses of the prose induction.
