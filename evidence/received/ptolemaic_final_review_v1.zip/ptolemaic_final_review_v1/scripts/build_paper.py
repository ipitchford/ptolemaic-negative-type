#!/usr/bin/env python3
"""Build the paper, and optionally the review guide, using installed LaTeX.

No packages are fetched. Intermediate files go to a temporary directory.
Output must be outside the immutable review bundle.
"""
from __future__ import annotations
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT=Path(__file__).resolve().parents[1]

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--guide',action='store_true')
    a=p.parse_args(); out=a.output.expanduser().resolve()
    if out.is_relative_to(ROOT): p.error('Choose an output directory outside the review bundle.')
    if not shutil.which('pdflatex'): p.error('pdflatex is required; install a LaTeX distribution separately.')
    out.mkdir(parents=True,exist_ok=True)
    sources=[ROOT/'paper/ptolemaic.tex']
    if a.guide: sources.append(ROOT/'review/REVIEW_GUIDE.tex')
    for source in sources:
        with tempfile.TemporaryDirectory(prefix='ptolemaic-typeset-') as tmp:
            env=dict(os.environ,SOURCE_DATE_EPOCH='1790294400',FORCE_SOURCE_DATE='1')
            for step in range(3):
                q=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error',
                                  f'-output-directory={tmp}',source.name],cwd=source.parent,
                                 env=env,capture_output=True,text=True,timeout=180)
                if q.returncode:
                    (out/f'{source.stem}.failed.log').write_text(q.stdout+'\n'+q.stderr)
                    raise RuntimeError(f'LaTeX failed for {source.name}; inspect the output log.')
            log=(Path(tmp)/f'{source.stem}.log').read_text(errors='replace')
            for token in ('undefined references','undefined citations','Overfull \\hbox','Overfull \\vbox'):
                if token in log: raise RuntimeError(f'{source.name}: unresolved typesetting warning: {token}')
            shutil.copy2(Path(tmp)/f'{source.stem}.pdf',out/f'{source.stem}.pdf')
            (out/f'{source.stem}.log').write_text(log)
    print('Build complete. PDF bytes can vary with TeX/font versions; inspect rendering after rebuilding.')

if __name__=='__main__': main()
