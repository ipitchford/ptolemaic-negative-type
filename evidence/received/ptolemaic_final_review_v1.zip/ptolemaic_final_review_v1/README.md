# Sharp negative type of finite Ptolemaic metrics
## Final-review package — version 1.0-rc1 — 25 September 2026

**Start with `paper/ptolemaic.pdf`, then `review/REVIEW_GUIDE.pdf`.** The paper states an analytic proof of the sharp universal exponent for every cardinality at least six. The all-cardinality corollary appends the known small cases. No proof-assistant verification, external specialist peer review, journal acceptance or public deposition is claimed.

The principal formula is

\[
P(m)=\log_2\!\left(1+\frac{m}{\lfloor(m-1)^2/4\rfloor}\right),\quad m\ge3.
\]

The proof uses a star-packing theorem, a conditional induction on normalised augmented-inverse entries, and a separate strong induction on metric cardinality. Its positive-definiteness assumptions are discharged on strictly smaller Ptolemaic metrics at the same exponent. Appendix B makes these obligations explicit.

### Contents

| Path | Purpose |
|---|---|
| `paper/ptolemaic.pdf` | The review manuscript. |
| `paper/ptolemaic.tex` | Authoritative editable source; references are included in the file. |
| `paper/references.bib` | Bibliographic metadata for reuse; not needed to compile this manuscript. |
| `review/REVIEW_GUIDE.pdf` and `.md` | Reading route, dependencies, review questions and evidence limitations. |
| `review/CLAIM_CHECK_MAP.csv` | Theorems and equations mapped to checks and remaining analytic review obligations. |
| `review/EVIDENCE_LEDGER.md` | Exact versus numerical evidence; missingness and replay differences. |
| `review/SOURCE_LEDGER.md` | Versioned sources, what is imported, and bounds on source verification. |
| `review/CHANGELOG.md` | Changes from the received derivation to this paper. |
| `review/RELEASE_METADATA.json` | Version, provenance and unresolved publication fields. |
| `evidence/core/` | Original all-size proof package, extracted unchanged. |
| `evidence/supplied/` | Supplied audit scripts/reports, copied unchanged. |
| `evidence/current/` | Fresh replay logs, reports, environment and manuscript-specific checks. |
| `evidence/received/` | Three received ZIPs preserved byte-for-byte. |
| `replay_review.py` | Integrity verification and evidence replay in temporary directories. |
| `scripts/` | Supplemental checks and a no-network LaTeX build utility. |
| `SHA256SUMS` | Manifest of every shipped file except the manifest itself. |

### Reproduce the evidence

Use Python 3.11 or later. The recorded environment uses Python 3.13.5; numerical package versions are pinned in `requirements.txt`. Install dependencies in an environment you control:

```sh
python -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
python replay_review.py --mode exact --output ../ptolemaic-exact-replay
python replay_review.py --mode full --output ../ptolemaic-full-replay
```

Dependency installation requires access to a package source; replay itself makes no network requests. `--mode integrity` checks only file hashes. Exact mode runs the original rational and symbolic checks plus the new manuscript checks. Full mode additionally runs the original numerical checks and all three supplied audit scripts. **Do not run with `python -O`: the received verifiers use assertions.**

The wrapper copies executable evidence into temporary directories. It never overwrites the shipped inputs or reports. Choose an output directory outside this package, or omit `--output` to use a temporary directory. Exact reports must match their shipped bytes. Floating-point reports are retained and compared, but byte differences are reported rather than treated as theorem refutations. Inspect the evidence ledger before interpreting any optimiser deficit.

### Rebuild the documents

A LaTeX distribution with `pdflatex`, `newtx`, `amsmath`, `amsthm`, `mathtools`, `natbib`, `hyperref` and `cleveref` is required. The build script does not fetch packages.

```sh
python scripts/build_paper.py --output ../ptolemaic-rebuilt --guide
```

The paper's theorem numbering is authoritative. PDF bytes can depend on the TeX/font versions; after a rebuild, inspect page layout as well as log warnings. No font files are distributed in this package.

### Assurance and release boundary

A correct identity checker is not a proof of the universal analytic argument. The supplied audit is preserved as a review artefact; its author identity and independence are not independently established here. Its subjective probability and quality score are not calibration data and are not repeated as scientific assurance in the manuscript.

The manuscript is anonymous at the user's instruction. No person is credited or assigned release responsibility. There is no minted DOI, licence grant, journal submission, public upload or claim that every equality case is classified. These fields remain for the release decision after final review.
